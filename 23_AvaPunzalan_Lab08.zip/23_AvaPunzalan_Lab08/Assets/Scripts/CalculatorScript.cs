﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class CalculatorScript : MonoBehaviour
{

    private float SGDUSD_rate = 0.72f;
    private float SGDJPY_rate = 82.78f;
    private float SGDRM_rate = 3.08f;
    private float SGDEUR_rate = 0.63f;
    private float SGDKRW_rate = 881.54f;
    private float SGDTWD_rate = 20.73f;

    public InputField inputConvertedAmount;
    public InputField inputAmount;

    public Text debugText;

    public Toggle usdT;
    public Toggle yenT;
    public Toggle rmT;
    public Toggle eurT;
    public Toggle wonT;
    public Toggle twdT;


    void Start()
    {
        debugText.GetComponent<Text>().text = "";
    }

    //Button to convert SGD to US/JPY
    public void ConvertToDollar(Toggle toggleUSDollar)
    {

        try
        {
            float amount = float.Parse(inputAmount.text);

            if (usdT.isOn == true)
            {
                inputConvertedAmount.text = "$" + (amount * SGDUSD_rate);
            }
            else if (yenT.isOn == true)
            {
                inputConvertedAmount.text = "$" + (amount * SGDJPY_rate);
            }
            else if (rmT.isOn == true)
            {
                inputConvertedAmount.text = "$" + (amount * SGDRM_rate);
            }
            else if (eurT.isOn == true)
            {
                inputConvertedAmount.text = "$" + (amount * SGDEUR_rate);
            }
            else if (wonT.isOn == true)
            {
                inputConvertedAmount.text = "$" + (amount * SGDKRW_rate);
            }
            else if (twdT.isOn == true)
            {
                inputConvertedAmount.text = "$" + (amount * SGDTWD_rate);
            }
            //Toggle JPToggle = GameObject.Find("JapanToggle").GetComponent<Toggle>();

            ////converts to US Dollar
            //if (JPToggle.isOn == false && toggleUSDollar.isOn == true)
            //{
            //    inputConvertedAmount.text = "$" + (amount * SGDUSD_rate);
            //}
            ////converts to Japanese Yen
            //else if (JPToggle.isOn == true && toggleUSDollar.isOn == false)
            //{
            //    inputConvertedAmount.text = "$" + (amount * SGDJPY_rate);
            //}
            ////will not calculate and call in debug
            //else
            //{
            //    debugText.text = "Select Currency First";
            //}

            ////debug calls when both toggles are on
            //if (JPToggle.isOn == true && toggleUSDollar.isOn == true)
            //{
            //    inputConvertedAmount.text = "$";
            //    debugText.text = "Choose Only One Currency";
            //}

        }
        catch (System.FormatException)
        {
            //debug will call when the amount input is not typed in numbers
            debugText.text = "Please Enter A Valid Amount";
        }
    }

    public void ClearBtn()
    {
        //restart calculator
        SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);

    }



}
